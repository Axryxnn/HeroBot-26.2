PHONE-ONLY CLOUD BUILD

You do not need a computer. This ZIP now includes a GitHub Actions workflow that asks GitHub's cloud runner to install Java 25 and build the Fabric mod.

Read PHONE-BUILD-GUIDE.md for step-by-step instructions using an Android phone.

The build is not automatically tested in Minecraft. If the cloud build succeeds, download its artifact from GitHub Actions and send me the build log or JAR details so I can help with runtime verification.
