# Build HeroBot 26.2 using only an Android phone

You do not need a PC to trigger the cloud build. GitHub Actions can build this source on GitHub's servers with Java 25.

## Steps
1. Sign in to https://github.com/ (create a free account if needed).
2. Create a new repository. A simple name is `HeroBot-26.2-port`.
3. On the repository page, use **Add file → Upload files** in your phone browser.
4. Extract this ZIP on your phone first, then upload the *contents* of the `HeroBot-26.2-port` folder. Make sure `.github/workflows/build-26.2.yml` is included. If the `.github` folder is hidden, enable **Show hidden files** in your file manager.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build HeroBot for Minecraft 26.2** and open the latest run.
7. If it succeeds, scroll to **Artifacts** and download `HeroBot-Minecraft-26.2-Fabric`. Extract it; the `.jar` inside is the build output.

If it fails, open the failed run, expand the red failed step, and copy or screenshot the error log here. I can then fix the source and prepare another ZIP.

## Important
A successful build only confirms compilation and JAR structure. It does not prove the mod works in-game. The final JAR still needs a Minecraft 26.2 Fabric client test, including mixin startup and HeroBot features.
