# HeroBot — Minecraft 26.2 Fabric port status

This is a source migration workspace based on the uploaded HeroBot 2.6.5 source archive. It is not the original 1.4.3 binary JAR.

## Changes in this revision

- Targeted Minecraft `26.2`, Java toolchain/release `25`.
- Updated to Fabric Loader `0.19.5`, Fabric API `0.161.0+26.2`, Fabric Loom `1.17.21`, Gradle wrapper `9.6.1`.
- Kept the non-remapping Loom plugin (`net.fabricmc.fabric-loom`) and removed Yarn mappings.
- Fixed the previous migration's accidental corruption of Java package/import paths (`client.screen.ai` had been changed to invalid `client.gui.screen().ai`).
- Migrated direct client screen access to `Minecraft.gui.screen()` / `Minecraft.gui.setScreen(...)`, and overlay access to `Minecraft.gui.overlay()`.
- Corrected the distributable build path for unobfuscated Minecraft: the shaded Fabric artifact is produced by `shadowJar`; no `remapJar` task is used. The thin development JAR is separated under `build/devlibs`.
- Kept the optional Carpet dependency pinned to the published Carpet 26.2 artifact.
- Kept the Paper plugin out of this Fabric-only build; it still targets its original platform/version.

## Static checks completed

- Parsed all 233 Java source files with the JDK compiler parser: **0 Java syntax errors**.
- Checked Java package declarations against their source paths: **0 mismatches**.
- Parsed all three Mixin JSON configurations and checked that every configured mixin class exists: **0 missing mixin classes**.
- Confirmed there are no stale `remapJar` build references.

These are structural checks only. They do **not** prove that Minecraft 26.2 method/field descriptors or injection points still match.

## Not yet verified

**No successful Gradle compile, remapped/shaded JAR, client launch, or dedicated-server launch has been produced in this environment.** The environment has only OpenJDK 21, while 26.1+ requires Java 25, and outbound DNS/network access is unavailable, preventing Gradle and dependency downloads. Therefore compile-time API errors and runtime Mixin failures cannot be enumerated or honestly marked fixed here.

The remaining validation must run on a machine with JDK 25 and network access:

```bash
./gradlew :herobot-mod:build --stacktrace
```

The distributable shaded JAR should appear in `herobot-mod/build/libs/`. Then test both a Fabric client and a dedicated server with Fabric Loader 0.19.5, Fabric API 0.161.0+26.2, and (if using Carpet compatibility) Carpet 26.2. Check the startup log for Mixin application errors and exercise bot spawning, movement/pathing, inventory actions, scripting/editor UI, and disconnect/reconnect flows.

Do not install this source ZIP as a mod. It is not a compiled/playable JAR.
