package hero.bane.herobot.mod.common.mixin;

import hero.bane.herobot.mod.common.rule.ModRules;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.material.PushReaction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ShulkerBoxBlockEntity.class)
public class ShulkerBoxBlockEntityMixin {
    @Redirect(method = "moveCollidedEntities", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;getPistonPushReaction()Lnet/minecraft/world/level/material/PushReaction;"
    ))
    private PushReaction getPistonBehaviourOfNoClipPlayers(Entity entity) {
        if (ModRules.isCreativeNoClipFlying(entity))
            return PushReaction.IGNORE;
        return entity.getPistonPushReaction();
    }
}
