# HeroBot — Minecraft 26.2 Fabric source port

This workspace is a best-effort migration of the supplied HeroBot source to Fabric for Minecraft 26.2.

- Target: Minecraft 26.2 / Fabric / Java 25
- Build: `./gradlew :herobot-mod:build`
- Distribution: `herobot-mod/build/libs/`
- Port status and verification limits: see [PORTING-STATUS.md](PORTING-STATUS.md)

**Important:** this is source code, not a ready-to-install mod JAR. The build and in-game Mixin checks have not yet been run because the current build environment lacks JDK 25 and outbound dependency-download access.
